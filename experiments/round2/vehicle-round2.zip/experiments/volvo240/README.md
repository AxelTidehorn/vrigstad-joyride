# Current vehicle refinement — round 2

Current shared fleet review: [round 2](../round2/index.html). Current technical
report, preserved geometry, source reproduction and limitations are documented
in [the round-2 report](../round2/README.md) and its summary.json. Canonical master
and GLB filenames below now contain the round-2 geometry. Earlier renders and
per-stage ZIPs remain historical checkpoints; the current source/model package
is `../round2/vehicle-round2.zip`. Game integration is pending visual approval.

The earlier stage descriptions below are historical.

---

# Current Volvo 240 refinement — controlled wheel arches

Latest editable master: `refinement/model.blend`; GLB: `refinement/review-only.glb`.
[Same-camera before/after review](refinement/arch-review/index.html) includes side,
front/rear three-quarter and wheel-arch close-ups, with and without wheels.
See [assessment](refinement/assessment.md) for preserved geometry and limitations.

The latest pass edits the existing Blender body locally. `refine_forms.py` is shared
by the direct-edit adapter `refine_existing.py` and the end of the existing
`model.py`, so source regeneration and the edited master stay aligned. Opening
profiles remain parametrically editable in `parameters.json: arch_refinement`.
All 24 separate component meshes and the vehicle's primary proportions are retained.
The unchanged exporter/validator passes; 6162 total triangles, 25 mesh objects.

Codex/maintainer reproduction (no viewer-side setup):

```sh
# Edit the existing master once; adapter is idempotent on an already refined file.
python "$BMOD" --script experiments/volvo240/refine_existing.py \
  --blend path/to/frozen-previous-master.blend --out /tmp/240-edit --check -- \
  experiments/volvo240/refinement/model.blend
# Same fixed cameras for both masters:
python "$BMOD" --script experiments/volvo240/arch_review.py \
  --blend experiments/volvo240/refinement/model.blend --out /tmp/240-review -- \
  experiments/volvo240/refinement/arch-review/after
blender -b --python-exit-code 1 --python tools/vehicle_pipeline/blender_import.py -- \
  --source experiments/volvo240/refinement/model.blend \
  --output experiments/volvo240/refinement/review-only.glb \
  --previews experiments/volvo240/refinement/repository_previews
python tools/vehicle_pipeline/validate.py experiments/volvo240/refinement/review-only.glb \
  experiments/volvo240/vehicle.json --report experiments/volvo240/refinement/glb_geometry.json
blender -b --python-exit-code 1 --python tools/vehicle_pipeline/reimport_check.py -- \
  experiments/volvo240/refinement/review-only.glb
node tools/vehicle_pipeline/check_preview_glb.mjs experiments/volvo240/refinement/review-only.glb \
  experiments/volvo240/refinement/arch-review/three-loader.json
python experiments/volvo240/package_arch_review.py
```

`arch_audit.py` accepts the frozen previous master and output folder through
Blender Modeler script mode. Restore that master from parent commit `f064b57` into
a temporary path; do not overwrite the current master. It verifies body closure,
winding, degeneracy, BVH contacts, bounds and preservation of protected geometry.
`arch_repro.py` compares a source-generated temporary `.blend` against the edited
master. JSON proof is retained under `refinement/arch-review/`. The source check
uses the existing pinned Modeler and `model.py`; it does not create a second design.

The earlier experimental notes below are historical and do not describe the
current export status or current wheel-arch construction.

---

Current refinement comparisons (iPad, no setup):
https://vrigstad-240-review-179ef06.plushpangolin8.chatgpt.site/refinement/

Current editable file: `refinement/model.blend`. Current report: `refinement/assessment.md`.
The previous iter_00–02 checkpoint below remains preserved as historical evidence.
The refined review-only GLB passes the unchanged validator; human approval is pending.

# Volvo 240 clay experiment — review required, NOT game ready

Open the hosted review in Safari (no local setup):
https://vrigstad-240-review-179ef06.plushpangolin8.chatgpt.site

The page provides touch rotation, pinch/zoom buttons, five fixed views, film or
neutral clay treatment, PNG sheets, reference comparison and downloadable source.
It uses private access for the owner account. All Blender work runs in Codex.
See `art-direction.md` for the stylized-realism brief.

Isolated branch: `experiment/volvo-240-clay-blockout`.
Base: `AxelTidehorn/vrigstad-joyride` commit
`8d7198c3f81361c964cf3e0f988e84584dcd761e`.

Blender **4.3.2** ran headlessly and produced real images. No installation was
needed. This work stops after the initial blockout and **two correction cycles**.
No PR, integration, physics change or existing car asset change was made.

Open `renders/iter_02/model.blend`. Source is `model.py` plus `parameters.json`.
The body is an editable triangulated mesh generated from a parametric loft;
change the source parameters to regenerate the loft rather than hand-editing an
export. Parameter/source snapshots for earlier iterations are alongside their
renders. See `references.md` for sources, licences, uncertainties and dimensions;
`notes.md` for the visual review and remaining errors.

## Reproduce a single run

From the repository root, using a Python virtual environment:

```sh
python3 -m venv work/vehicle-venv
work/vehicle-venv/bin/pip install -r tools/vehicle_pipeline/requirements.txt
# External modelling/check/render helpers; keep this separate from the game.
git clone https://github.com/calebrisc/blender-modeler.git work/blender-modeler
git -C work/blender-modeler checkout c8f245982108e2627972768d4311cbe172b58137
work/vehicle-venv/bin/python experiments/volvo240/run.py \
  --modeler work/blender-modeler --out work/volvo240-review
```

Requires Blender 4.2+ on PATH (repository exporter needs 4.x+). For another binary,
pass `--blender /absolute/path/to/blender`. The pinned upstream Modeler scripts
remain unchanged. A successful generation is not an approval: **the supplied
final source is expected to produce a rejected GLB and return a nonzero status**.
`run.py` preserves stage logs, checks supplemental findings and invokes the
repository exporter/validator without repairing the result.

The commands below are for Codex/maintainers, not setup required from viewers.
The exact commands used for the saved runs are in `notes.md`. Existing regression
checks: `python -m unittest discover -s tests -p 'test_vehicle_*.py' -v` (5 passed).
The orchestration wrapper was syntax/help checked; the saved iterations were
run with the individual documented commands, not rerun through the wrapper after
the correction limit.

## Existing pipeline reuse and compatibility

- Read `AGENTS.md`, `ARCHITECTURE.md`, vehicle pipeline README and game README.
- Inspected and used `tools/vehicle_pipeline/blender_import.py` unchanged: strict
  Blender body gate, GLB export with `export_yup=True`, four repository previews.
- Used `tools/vehicle_pipeline/validate.py` unchanged with `vehicle.json`. No
  asset stretch, validator weakening or post-export geometry repair.
- Used Blender Modeler `bmod.py`, `modelkit.py`, `check_geometry.py` and
  `render_views.py`; followed its SKILL.md and techniques reference. Pin above.
- `review.py` is a small camera/color adapter and extra audit, not an alternative
  exporter. Modeler defaults to -Y front; the repository requires **+Y front**,
  +X vehicle right and +Z up, in metres. The adapter keeps repository coordinates.
  All four wheel names follow the repository requirement.
- `media/vehicles/preview.html` was inspected. It assumes Kenney +Z-forward
  sources, rotates them and normalizes length to 4.35 m; loading this experiment
  there unchanged would misrepresent scale/orientation. The follow-up viewer
  task now extends it with per-asset conventions: Volvo keeps authored metres
  and -Z forward; Kenney candidates retain their previous review transforms.
  Existing exporter and Modeler PNGs remain available unchanged.
- Repository front/side/rear previews are slightly elevated. Additional Modeler
  front/side/rear/top views are true orthographic; three-quarter views use a
  fixed 50 mm perspective camera. Cameras/framing are identical across revisions.

The eight-view sheet has FRONT | SIDE | REAR | TOP on row 1, and right front
three-quarter | left front three-quarter | rear three-quarter | low front on row 2.
Modeler's sheet builder has no labels; this order is recorded here explicitly.

Clay colors distinguish the glazing envelope and wheel masses only. No textures,
lighting presentation pass, lamps, trim, police equipment or cosmetic detailing.
Vertex colors keep glazing within the connected closed body and one GLB material.
Four lathed wheel envelopes include small hub extensions into the inner well
walls (25 mm nominal attachment overlap); the tread clears the 365 mm radius
wheel well by 50 mm nominal radially. Full suspension and inner fenders are not
modeled. Wheel origin placement still needs a runtime animation review.

The `.blend` is inspectable. The `.glb` is retained **only as rejected validation
evidence**. Neither is approved for integration or a recognizable-Volvo claim.

The unchanged repository Workbench preview uses material diffuse colors and does
not display the shader's vertex-color glazing. Use `clay_*.png` from the Modeler
adapter for the readable glazing envelope; use `repository_previews/` as the
unaltered pipeline render evidence. No presentation shaders were substituted.
